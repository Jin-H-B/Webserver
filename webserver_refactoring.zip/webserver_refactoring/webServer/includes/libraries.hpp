#ifndef CPPLIBRARY_HPP
#define CPPLIBRARY_HPP

#include <iostream>
#include <string>
#include <sys/time.h>
#include <sys/event.h>
#include <sys/types.h>
#include <vector>
#include <iterator>
#include <iostream>
#include <string>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <unistd.h>
#include <fcntl.h>
#include <errno.h>
#include <ctime>
#include <map>
#include <vector>
#include <list>
#include <algorithm>
#include <iterator>
#include <sstream>
#include <exception>
#include <sys/stat.h>
#include <dirent.h>

#endif
